package com.example.bjjherofyp;


import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;


public class RegisterAcitivity extends AppCompatActivity {

    EditText MemberEmail,MemberPassword,MemberPasswordCheck;
    Button RegisterButton,movetologin;
    FirebaseAuth fAuth;
    String adminEmail ="j@gmail.com";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_acitivity);



        MemberEmail = findViewById(R.id.MemberEmail);
        MemberPassword = findViewById(R.id.MemberPassword);
        RegisterButton = findViewById(R.id.RegisterButton);
        movetologin = findViewById(R.id.MoveToLogin);
        MemberPasswordCheck = findViewById(R.id.MemberPasswordCheck);


        fAuth = FirebaseAuth.getInstance();


        //check if user is already logged in just send them to the main activity

        if (fAuth.getCurrentUser() != null) {


            startActivity(new Intent(getApplicationContext(), MainActivity.class));
            finish();

        }


        RegisterButton.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {


                String email = MemberEmail.getText().toString().trim();
                String password = MemberPassword.getText().toString().trim();
                String passwordcheck = MemberPasswordCheck.getText().toString().trim();



                //check if the email field is empty
                if (TextUtils.isEmpty(email)) {


                    MemberEmail.setError("email must not be empty ");
                    return;
                }



                //check if email is in the correct format
                String regex = "^[A-Za-z0-9+_.-]+@(.+)$";


                if (email.matches(regex) == false){


                    MemberEmail.setError("email must be in @ format");
                    return;
                }




                //check if the password field is empty
                if (TextUtils.isEmpty(password) ) {


                    MemberPassword.setError("password cannot be left empty");
                    return;
                }




                //CHECK THAT THE PASSWORD IS GREATER THAN 6 CHARACTERS
                if (password.length() < 6 ) {

                    MemberPassword.setError("password must be greater than 6 characters");
                    return;
                }





                //check if the password entered is repeated correctly
               if (!(passwordcheck).equals(password)){

                   MemberPassword.setError("Passwords do not match please try again ");
                   return ;
              }



                fAuth.createUserWithEmailAndPassword(email, password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {

                        if (task.isSuccessful()) {

                            //user created   put toast message

                            Toast toast1 = Toast.makeText(getApplicationContext(), "Registration successful",Toast.LENGTH_SHORT);
                            toast1.show();

                            if(email.equals(adminEmail)) {

                                startActivity(new Intent(getApplicationContext(), MainActivity.class));
                                //login was a success

                            }else{

                                startActivity(new Intent(getApplicationContext(),clientSide.class));

                            }


                        }
                        else {

                            //user not created toast message

                            Toast toast2 = Toast.makeText(getApplicationContext(), "Registration failed ",Toast.LENGTH_SHORT);
                            toast2.show();

                        }
                    }
                });
            }
        });



            movetologin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                startActivity(new Intent(getApplicationContext(),loginActivity.class));
            }
        });
    }
}
