package com.example.bjjherofyp;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class clubMembers extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_club_members);
    }
}
