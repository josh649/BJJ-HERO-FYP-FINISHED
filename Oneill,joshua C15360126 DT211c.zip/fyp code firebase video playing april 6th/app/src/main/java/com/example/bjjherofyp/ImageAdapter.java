package com.example.bjjherofyp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;

import java.util.List;

public class ImageAdapter extends RecyclerView.Adapter<ImageAdapter.ImageViewHolder> {
    private Context mContext;
    private List<Upload> mUploads;
    private OnItemClickListener mlistener;

    public ImageAdapter(Context context, List<Upload> uploads) {
        mContext = context;
        mUploads = uploads;
    }


public void  setOnItemClickListener(OnItemClickListener listener){


        mlistener =listener ;
    }

    public interface OnItemClickListener{
        void OnItemClickListener(int position);

    }


    public void setUploads(List<Upload> uploads) {
        this.mUploads = uploads;
        this.notifyDataSetChanged();
    }
    @Override
    public ImageViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(mContext).inflate(R.layout.image_item, parent, false);
        return new ImageViewHolder(v,mlistener);


    }

    @Override
    public void onBindViewHolder(ImageViewHolder holder, int position) {
        Upload CurrentPicture = mUploads.get(position);
        holder.textViewName.setText(CurrentPicture.getName());





        Picasso.get()
                .load(CurrentPicture.getImageUrl())
                .fit()
                .centerCrop()
                .placeholder(R.mipmap.ic_launcher)
                .into(holder.imageView);




    }

    @Override
    public int getItemCount() {
        return mUploads.size();
    }

    public class ImageViewHolder extends RecyclerView.ViewHolder {
        public TextView textViewName;
        public ImageView imageView;

        public ImageViewHolder(View itemView,OnItemClickListener listener) {
            super(itemView);

            textViewName = itemView.findViewById(R.id.text_view_name);
            imageView = itemView.findViewById(R.id.image_view_upload);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(listener != null){


                        int position = getAdapterPosition();
                        if(position != RecyclerView.NO_POSITION){

                            listener.OnItemClickListener(position);
                        }
                    }

                }
            });
        }
    }
}