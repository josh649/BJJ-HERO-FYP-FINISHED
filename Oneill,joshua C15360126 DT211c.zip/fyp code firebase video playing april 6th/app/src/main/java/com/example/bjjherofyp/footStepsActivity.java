package com.example.bjjherofyp;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

import com.anychart.AnyChart;
import com.anychart.AnyChartView;
import com.anychart.chart.common.dataentry.DataEntry;
import com.anychart.chart.common.dataentry.ValueDataEntry;
import com.anychart.charts.Funnel;

import java.util.ArrayList;
import java.util.List;

public class footStepsActivity extends AppCompatActivity {

    EditText calories,hours;
    Button getAllData;
    AnyChartView anyChartView;




    String content1;
    String content2;
    String content3;
    String content4;
    String content5;


    String footstepsmoved1;
    String footstepsmoved2;
    String footstepsmoved3;
    String footstepsmoved4;
    String footstepsmoved5;

    double footstepsdouble1;
    double footstepsdouble2;
    double footstepsdouble3;
    double footstepsdouble4;
    double footstepsdouble5;





















    String URL = "http://64.225.99.10:5000/time?time=";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_foot_steps);


        calories = (EditText) findViewById(R.id.caloriesRetrieved);
        hours = (EditText) findViewById(R.id.HourWanted);
        getAllData = (Button) findViewById(R.id.getData);

        Funnel funnel = AnyChart.funnel();

        anyChartView=findViewById(R.id.any_chart_view);





        footstepsmoved1=getIntent().getExtras().getString("value6");

        footstepsmoved2=getIntent().getExtras().getString("value7");

        footstepsmoved3=getIntent().getExtras().getString("value8");
        footstepsmoved4=getIntent().getExtras().getString("value9");

        footstepsmoved5=getIntent().getExtras().getString("value10");




        content1=getIntent().getExtras().getString("value21");

        content2=getIntent().getExtras().getString("value22");

        content3=getIntent().getExtras().getString("value23");

        content4=getIntent().getExtras().getString("value24");

        content5=getIntent().getExtras().getString("value25");





        footstepsdouble1 = Double.parseDouble(footstepsmoved1);
        footstepsdouble2 = Double.parseDouble(footstepsmoved2);
        footstepsdouble3 = Double.parseDouble(footstepsmoved3);
        footstepsdouble4 = Double.parseDouble(footstepsmoved4);
        footstepsdouble5 = Double.parseDouble(footstepsmoved5);





        System.out.println(footstepsdouble1+" " +footstepsdouble2+" " +footstepsdouble3+" " +footstepsdouble4+" "+footstepsdouble5 +"steps printed from steps");

        System.out.println(content1+" " +content2+" " +content3+" " +content4 +" "+content5+" content printed from footsteps");




        String[] hoursChart ={content1,content2,content3,content4,content5};
        double[] caloriesChart={footstepsdouble1,footstepsdouble2,footstepsdouble3,footstepsdouble4,footstepsdouble5};

        setupColumnChart(hoursChart,caloriesChart);

    }



    public  void setupColumnChart(String[] hoursChart, double[] caloriesChart){

      //  Cartesian bar = AnyChart.column();

        Funnel funnel = AnyChart.funnel();
        List<DataEntry> dataEntries = new ArrayList<>();

        for(int i=0;i<hoursChart.length;i++){

            dataEntries.add(new ValueDataEntry(hoursChart[i],caloriesChart[i]));

        }


        funnel.data(dataEntries);
        anyChartView.setChart(funnel);
        funnel.title("steps taken during training");

    }


}
