package com.example.bjjherofyp;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.Timestamp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.Date;



public class clientSide extends AppCompatActivity implements  View.OnClickListener{

        public Button ViewTimeTable;
        public Button ViewTechniques;
        public Button UploadWorkout;
        public Button ViewWorkouts;
        public Button social;
        public Button fitbit;
        public Button Logout;




        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.client_side);


            ViewTimeTable = (Button) findViewById(R.id.View_timetable);
            ViewTechniques = (Button) findViewById(R.id.view_techniques);
            UploadWorkout = (Button) findViewById(R.id.uploadWorkout);
            ViewWorkouts =(Button)findViewById(R.id.View_logged_workouts);
            social =(Button)findViewById(R.id.social_media_feed);
            fitbit = (Button) findViewById(R.id.Retrieve_fitness_data);
            Logout = (Button) findViewById(R.id.Logout_button);





            ViewTimeTable.setOnClickListener(this);
            UploadWorkout.setOnClickListener(this);
            fitbit.setOnClickListener(this);
            social.setOnClickListener(this);
            ViewTechniques.setOnClickListener(this);
            ViewWorkouts.setOnClickListener(this);
            Logout.setOnClickListener(this);


        }



        @Override
        public void onClick(View v)
        {
            if (v == ViewTimeTable)
            {
                // go to different activity
                Intent myIntent = new Intent(this, ImagesActivity.class);
                startActivity(myIntent);
            }
            if(v == ViewTechniques)

            {
                Intent myIntent = new Intent(this, youtubePlayer.class);
                startActivity(myIntent);
            }

            if(v == UploadWorkout)
            {
                showAlertDialog();

            }
            if(v == ViewWorkouts)
            {
                // go to different activity
                Intent myIntent = new Intent(this,ViewMyNotes.class);
               startActivity(myIntent);
            }
            if(v == fitbit)
            {
                // go to different activity
                Intent myIntent = new Intent (this, VideoPlayer.class);
                startActivity(myIntent);
            }
            if(v == social)
            {
                // go to different activity
                Intent myIntent = new Intent (this, test1.class);
                startActivity(myIntent);
            }

            if(v ==Logout)
            {

                FirebaseAuth.getInstance().signOut();
                startActivity(new Intent(getApplicationContext(), loginActivity.class));
                finish();
            }
        }



    private void addNote(String text) {

        String userId = FirebaseAuth.getInstance().getCurrentUser().getUid();
        Note note = new Note(text, false, new Timestamp(new Date()), userId);

        FirebaseFirestore.getInstance()
                .collection("notes")
                .add(note)
                .addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
                    @Override
                    public void onSuccess(DocumentReference documentReference) {
                        Toast.makeText(clientSide.this, "Note was saved .", Toast.LENGTH_SHORT).show();
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(clientSide.this, "Failed to save note", Toast.LENGTH_SHORT).show();
                    }
                });

    }

    private void showAlertDialog() {
        final EditText noteEditText = new EditText(this);
        new AlertDialog.Builder(this)
                .setTitle("Add a workout Log / Goal ")
                .setView(noteEditText)
                .setPositiveButton("Add", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        addNote(noteEditText.getText().toString());
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }



    private void initRecyclerView(FirebaseUser user){


    }



}

