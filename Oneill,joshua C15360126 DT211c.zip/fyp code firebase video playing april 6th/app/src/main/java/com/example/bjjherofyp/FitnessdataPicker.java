package com.example.bjjherofyp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

public class FitnessdataPicker extends AppCompatActivity implements View.OnClickListener {


    ImageView heartbeat, calories, footsteps, distance;

     String caloriesmoved1;
     String caloriesmoved2;
     String caloriesmoved3;
     String caloriesmoved4;
     String caloriesmoved5;

    String footstepsmoved1;
    String footstepsmoved2;
    String footstepsmoved3;
    String footstepsmoved4;
    String footstepsmoved5;

    String distancemoved1;
    String distancemoved2;
    String distancemoved3;
    String distancemoved4;
    String distancemoved5;



    String hearbeatmoved1;
    String hearbeatmoved2;
    String hearbeatmoved3;
    String hearbeatmoved4;
    String hearbeatmoved5;


    String content1;
    String content2;
    String content3;
    String content4;
    String content5;




    //distance going to distance class












    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fitnessdata_picker);

        heartbeat = findViewById(R.id.heartbeat);
        footsteps = findViewById(R.id.footsteps);
        distance = findViewById(R.id.distance);
        calories = findViewById(R.id.calories);


        heartbeat.setOnClickListener(this);
        footsteps.setOnClickListener(this);
        distance.setOnClickListener(this);
        calories.setOnClickListener(this);


        caloriesmoved1=getIntent().getExtras().getString("value1");

        caloriesmoved2=getIntent().getExtras().getString("value2");

        caloriesmoved3=getIntent().getExtras().getString("value3");

        caloriesmoved4=getIntent().getExtras().getString("value4");

        caloriesmoved5=getIntent().getExtras().getString("value5");


        footstepsmoved1=getIntent().getExtras().getString("value6");

        footstepsmoved2=getIntent().getExtras().getString("value7");

        footstepsmoved3=getIntent().getExtras().getString("value8");

        footstepsmoved4=getIntent().getExtras().getString("value9");

        footstepsmoved5=getIntent().getExtras().getString("value10");




        distancemoved1=getIntent().getExtras().getString("value11");

        distancemoved2=getIntent().getExtras().getString("value12");

        distancemoved3=getIntent().getExtras().getString("value13");

        distancemoved4=getIntent().getExtras().getString("value14");

        distancemoved5=getIntent().getExtras().getString("value15");




        hearbeatmoved1=getIntent().getExtras().getString("value16");

        hearbeatmoved2=getIntent().getExtras().getString("value17");

        hearbeatmoved3=getIntent().getExtras().getString("value18");

        hearbeatmoved4=getIntent().getExtras().getString("value19");

        hearbeatmoved5=getIntent().getExtras().getString("value20");





        content1=getIntent().getExtras().getString("value21");

        content2=getIntent().getExtras().getString("value22");

        content3=getIntent().getExtras().getString("value23");

        content4=getIntent().getExtras().getString("value24");

        content5=getIntent().getExtras().getString("value25");








        System.out.println(footstepsmoved1 +footstepsmoved2 +footstepsmoved3 +footstepsmoved4 +footstepsmoved5 +"printed from foot steps from picker class");


        System.out.println(caloriesmoved1 +caloriesmoved2 +caloriesmoved3 +caloriesmoved4 +caloriesmoved5 +"printed from fitness printed calroies from picker class ");



        System.out.println(distancemoved1 +distancemoved2 +distancemoved3 +distancemoved4 +distancemoved5 +"printed from  distance from picker class");



        System.out.println(hearbeatmoved1 +hearbeatmoved1 +hearbeatmoved3 +hearbeatmoved4 + hearbeatmoved5 +"printed from  heartbeat from picker class");


        System.out.println(content1 +content2 +content3 +content4+content5 +"content  from picker class");

    }



    public void onClickBtn (View v) {








    }



    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.footsteps:

                Intent myIntent = new Intent(this, footStepsActivity.class);



                myIntent.putExtra("value6",footstepsmoved1);
                myIntent.putExtra("value7",footstepsmoved2);
                myIntent.putExtra("value8",footstepsmoved3);
                myIntent.putExtra("value9",footstepsmoved4);
                myIntent.putExtra("value10",footstepsmoved5);
                myIntent.putExtra("value21",content1);
                myIntent.putExtra("value22",content2);
                myIntent.putExtra("value23",content3);
                myIntent.putExtra("value24",content4);
                myIntent.putExtra("value25",content5);

                startActivity(myIntent);
                break;
            case R.id.calories:
                //Do something



                Intent myIntent2 = new Intent(this, calorieActivity.class);

                myIntent2.putExtra("value1",caloriesmoved1);
                myIntent2.putExtra("value2",caloriesmoved2);
                myIntent2.putExtra("value3",caloriesmoved3);
                myIntent2.putExtra("value4",caloriesmoved4);
                myIntent2.putExtra("value5",caloriesmoved5);
                myIntent2.putExtra("value21",content1);
                myIntent2.putExtra("value22",content2);
                myIntent2.putExtra("value23",content3);
                myIntent2.putExtra("value24",content4);
                myIntent2.putExtra("value25",content5);




                startActivity(myIntent2);


                break;
            case R.id.distance:
                //Do something
                Intent myIntent4 = new Intent(this, distanceActivity.class);

                myIntent4.putExtra("value11",distancemoved1);
                myIntent4.putExtra("value12",distancemoved2);
                myIntent4.putExtra("value13",distancemoved3);
                myIntent4.putExtra("value14",distancemoved4);
                myIntent4.putExtra("value15",distancemoved5);
                myIntent4.putExtra("value21",content1);
                myIntent4.putExtra("value22",content2);
                myIntent4.putExtra("value23",content3);
                myIntent4.putExtra("value24",content4);
                myIntent4.putExtra("value25",content5);


                startActivity(myIntent4);
                break;
            case R.id.heartbeat:
                Intent myIntent3 = new Intent(this, heartBeatActivity.class);


                myIntent3.putExtra("value16",hearbeatmoved1);
                myIntent3.putExtra("value17",hearbeatmoved2);
                myIntent3.putExtra("value18",hearbeatmoved3);
                myIntent3.putExtra("value19",hearbeatmoved4);
                myIntent3.putExtra("value20",hearbeatmoved5);
                myIntent3.putExtra("value21",content1);
                myIntent3.putExtra("value22",content2);
                myIntent3.putExtra("value23",content3);
                myIntent3.putExtra("value24",content4);
                myIntent3.putExtra("value25",content5);


                startActivity(myIntent3);

        }

    }

}





