package com.example.bjjherofyp;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

import com.anychart.AnyChart;
import com.anychart.AnyChartView;
import com.anychart.chart.common.dataentry.DataEntry;
import com.anychart.chart.common.dataentry.ValueDataEntry;
import com.anychart.charts.Pie;

import java.util.ArrayList;
import java.util.List;


public class calorieActivity extends AppCompatActivity {


    String st;

    EditText calories,hours;
    Button getAllData;
    AnyChartView anyChartView;



    String content1;
    String content2;
    String content3;
    String content4;
    String content5;


    String caloriesmoved1;
    String caloriesmoved2;
    String caloriesmoved3;
    String caloriesmoved4;
    String caloriesmoved5;

    double caloriesdouble1;
    double caloriesdouble2;
    double caloriesdouble3;
    double caloriesdouble4;
    double caloriesdouble5;





String cal1;
    String cal2;
    String cal3;
    String cal4;
    String cal5;


    String when1;
    String when2;
    String when3;
    String when4;
    String when5;

    String day1;
    String day2;
    String day3;
    String day4;
    String day5;


    int f1;
    int f2;
    int f3;
    int f4;
    int f5;





    String URL = "http://64.225.99.10:5000/time?time=";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calorie);

        //used to access variables from a different class



        caloriesmoved1=getIntent().getExtras().getString("value1");

        caloriesmoved2=getIntent().getExtras().getString("value2");

        caloriesmoved3=getIntent().getExtras().getString("value3");

        caloriesmoved4=getIntent().getExtras().getString("value4");

        caloriesmoved5=getIntent().getExtras().getString("value5");






        content1=getIntent().getExtras().getString("value21");

        content2=getIntent().getExtras().getString("value22");

        content3=getIntent().getExtras().getString("value23");

        content4=getIntent().getExtras().getString("value24");

        content5=getIntent().getExtras().getString("value25");


        //change all calorie strings to floats
        caloriesdouble1 = Double.parseDouble(caloriesmoved1);
        caloriesdouble2 = Double.parseDouble(caloriesmoved2);
        caloriesdouble3 = Double.parseDouble(caloriesmoved3);
        caloriesdouble4 = Double.parseDouble(caloriesmoved4);
        caloriesdouble5 = Double.parseDouble(caloriesmoved5);





        System.out.println(caloriesdouble1+" " +caloriesdouble2+" " +caloriesdouble3+" " +caloriesdouble4 +" "+caloriesdouble5 +" calories printed from calories");


        System.out.println(content1+" " +content2+" " +content3+" " +content4 +" "+content5+" content printed from calories");






        String[] hoursChart ={content1,content2,content3,content4,content5};
         double[] caloriesChart={caloriesdouble1,caloriesdouble2,caloriesdouble3,caloriesdouble4,caloriesdouble5};



        calories = (EditText) findViewById(R.id.caloriesRetrieved);
        hours = (EditText) findViewById(R.id.HourWanted);
        getAllData = (Button) findViewById(R.id.getData);


        anyChartView=findViewById(R.id.any_chart_view);



        setupColumnChart(hoursChart,caloriesChart);

    }




    public  void setupColumnChart(String[] hoursChart, double[] caloriesChart){


        Pie pie = AnyChart.pie();
        List<DataEntry> dataEntries = new ArrayList<>();

        for(int i=0;i<hoursChart.length;i++){

            dataEntries.add(new ValueDataEntry(hoursChart[i],caloriesChart[i]));

        }


        pie.data(dataEntries);
        anyChartView.setChart(pie);
        pie.title("Calories burnt during training");

    }
}
