package com.example.bjjherofyp;

public class UploadVid{

        private String mName;
        private String mImageUrl;
        private String mLevel;

    public UploadVid()
        {
            //empty constructor needed
        }

    public UploadVid(String name, String url)
        {
            if (name.trim().equals(""))
            {
                name = "No Name";

            }

            this.mName = name;
            this.mImageUrl = url;

        }

        public String getName() {
        return mName;
    }

        public void setName(String name) {
        mName = name;
    }



        public String getUrl() {
        return mImageUrl;
    }

        public void setImageUrl(String url) {
        mImageUrl = url;
    }
    }
