package com.example.bjjherofyp;


import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TimePicker;

import androidx.appcompat.app.AppCompatActivity;

import java.text.SimpleDateFormat;
import java.util.Calendar;

public class test1 extends AppCompatActivity {


    String caloriesmoved1;
    String caloriesmoved2;
    String caloriesmoved3;
    String caloriesmoved4;
    String caloriesmoved5;

    String footstepsmoved1;
    String footstepsmoved2;
    String footstepsmoved3;
    String footstepsmoved4;
    String footstepsmoved5;


    String hearbeatmoved1;
    String hearbeatmoved2;
    String hearbeatmoved3;
    String hearbeatmoved4;
    String hearbeatmoved5;


    //distance going to distance class
    String distancemoved1;
    String distancemoved2;
    String distancemoved3;
    String distancemoved4;
    String distancemoved5;


    //string that holds date and time user wants data for
    String content1;
    String content2;
    String content3;
    String content4;
    String content5;

    //each data set saved to a variable for 20 different parts of data
    String d1cals;
    String d2cals;
    String d3cals;
    String d4cals;
    String d5cals;


    //distance
    String d1dis;
    String d2dis;
    String d3dis;
    String d4dis;
    String d5dis;


    String d1hrates;
    String d2hrates;
    String d3hrates;
    String d4hrates;
    String d5hrates;

    String d1steps;
    String d2steps;
    String d3steps;
    String d4steps;
    String d5steps;


    //test cases of variables to be moved and charted after arriving from API

    //calories going to calroies class


    String URL = "http://64.225.99.10:5000/data";

    EditText date_time_in1, date_time_in2, date_time_in3, date_time_in4, date_time_in5;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_test);

        date_time_in1 = findViewById(R.id.date_time_input1);


        date_time_in2 = findViewById(R.id.date_time_input2);


        date_time_in3 = findViewById(R.id.date_time_input3);


        date_time_in4 = findViewById(R.id.date_time_input4);


        date_time_in5 = findViewById(R.id.date_time_input5);


 /*      date_time_in1.setInputType(InputType.TYPE_NULL);
        date_time_in2.setInputType(InputType.TYPE_NULL);
        date_time_in3.setInputType(InputType.TYPE_NULL);
        date_time_in4.setInputType(InputType.TYPE_NULL);
        date_time_in5.setInputType(InputType.TYPE_NULL);*/


        date_time_in1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                showDateTimeDialog1(date_time_in1);


            }
        });

        date_time_in2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                showDateTimeDialog2(date_time_in2);


            }
        });


        date_time_in3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                showDateTimeDialog3(date_time_in3);


            }
        });

        date_time_in4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                showDateTimeDialog4(date_time_in4);

            }
        });

        date_time_in5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                System.out.println("hi");
                showDateTimeDialog5(date_time_in5);
            }

        });
    }




        public void  onClickBtn (View v) {

            String text = "100";


            caloriesmoved1 = "350.45";
            caloriesmoved2 = "150.54";
            caloriesmoved3 = "300.54";
            caloriesmoved4 = "200.34";
            caloriesmoved5 = "400.32";

            //foot steps going to footsteps class
            footstepsmoved1 = "1400.2112";
            footstepsmoved2 = "1000.212";
            footstepsmoved3 = "1650.8";
            footstepsmoved4 = "1200.2";
            footstepsmoved5 = "1050.9";

            //distance going to distance class
            distancemoved1 = "3.2112";
            distancemoved2 = "4.08";
            distancemoved3 = "2.8";
            distancemoved4 = "5.2";
            distancemoved5 = "3.9432";


            hearbeatmoved1 = "80";
            hearbeatmoved2 = "83";
            hearbeatmoved3 = "75";
            hearbeatmoved4 = "86";
            hearbeatmoved5 = "82";


            System.out.println("qwerty");


            String[] date_time_array = new String[5]; //declare with size
            content1 = date_time_in1.getText().toString(); //gets you the contents of edit text
            content2 = date_time_in2.getText().toString(); //gets you the contents of edit text
            content3 = date_time_in3.getText().toString(); //gets you the contents of edit text
            content4 = date_time_in4.getText().toString(); //gets you the contents of edit text
            content5 = date_time_in5.getText().toString(); //gets you the contents of edit text


            //send calories to other class test just change for real

            Intent myIntent = new Intent(this, FitnessdataPicker.class);
            myIntent.putExtra("value1", caloriesmoved1);
            myIntent.putExtra("value2", caloriesmoved2);
            myIntent.putExtra("value3", caloriesmoved3);
            myIntent.putExtra("value4", caloriesmoved4);
            myIntent.putExtra("value5", caloriesmoved5);


            myIntent.putExtra("value6", footstepsmoved1);
            myIntent.putExtra("value7", footstepsmoved2);
            myIntent.putExtra("value8", footstepsmoved3);
            myIntent.putExtra("value9", footstepsmoved4);
            myIntent.putExtra("value10", footstepsmoved5);

            myIntent.putExtra("value11", distancemoved1);
            myIntent.putExtra("value12", distancemoved2);
            myIntent.putExtra("value13", distancemoved3);
            myIntent.putExtra("value14", distancemoved4);
            myIntent.putExtra("value15", distancemoved5);


            myIntent.putExtra("value16", hearbeatmoved1);
            myIntent.putExtra("value17", hearbeatmoved2);
            myIntent.putExtra("value18", hearbeatmoved3);
            myIntent.putExtra("value19", hearbeatmoved4);
            myIntent.putExtra("value20", hearbeatmoved5);


            myIntent.putExtra("value21", content1);
            myIntent.putExtra("value22", content2);
            myIntent.putExtra("value23", content3);
            myIntent.putExtra("value24", content4);
            myIntent.putExtra("value25", content5);


            startActivity(myIntent);


            date_time_array[0] = content1;
            date_time_array[1] = content2;
            date_time_array[2] = content3;
            date_time_array[3] = content4;
            date_time_array[4] = content5;
/*

        String url1 = URL + content1.substring(9,11) + "&date=20" + content1.substring(0,8);
        System.out.println(url1);
        String url2 = URL + content2.substring(9,11) + "&date=20" + content2.substring(0,8);
        String url3 = URL + content3.substring(9,11) + "&date=20" + content3.substring(0,8);
        String url4 = URL + content4.substring(9,11) + "&date=20" + content4.substring(0,8);
        String url5 = URL + content5.substring(9,11) + "&date=20" + content5.substring(0,8);
        System.out.println(url5);
        List<String> url_list = new ArrayList<String>();
        url_list.add(url1);
        url_list.add(url2);
        url_list.add(url3);
        url_list.add(url4);
        url_list.add(url5);
*/




/*
        final JSONObject day1 = new JSONObject();
        try {
            day1.put("date", "20" + content1.substring(0,8));
            day1.put("time", content1.substring(9,11) );

        } catch (JSONException e) {
            e.printStackTrace();
        }

        final JSONObject day2 = new JSONObject();
        try {
            day2.put("date", "20" + content2.substring(0,8));
            day2.put("time", content2.substring(9,11) );

        } catch (JSONException e) {
            e.printStackTrace();
        }

        final JSONObject day3 = new JSONObject();
        try {
            day3.put("date", "20" + content3.substring(0,8));
            day3.put("time", content3.substring(9,11) );

        } catch (JSONException e) {
            e.printStackTrace();
        }

        final JSONObject day4 = new JSONObject();
        try {
            day4.put("date", "20" + content4.substring(0,8));
            day4.put("time", content4.substring(9,11) );

        } catch (JSONException e) {
            e.printStackTrace();
        }

        final JSONObject day5 = new JSONObject();
        try {
            day5.put("date", "20" + content5.substring(0,8));
            day5.put("time", content5.substring(9,11) );

        } catch (JSONException e) {
            e.printStackTrace();
        }




        final JSONObject body = new JSONObject();
        try {
            body.put("day1", day1);
            body.put("day2", day2);
            body.put("day3", day3);
            body.put("day4", day4);
            body.put("day5", day5);


        } catch (JSONException e) {
            e.printStackTrace();
        }
        System.out.println(body);


        // Instantiate the RequestQueue.
        RequestQueue queue = Volley.newRequestQueue(this);
        // Request a string response from the provided URL.

        StringRequest stringRequest = new StringRequest(Request.Method.POST, URL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        JSONObject jsonObject = null; // declare JSON object to hold the status
                        try {

                            //all my fitness data
                            jsonObject = new JSONObject(response); // get the response and store it into the JSONobject
                            // Get the response from on server*/


                            /*//gets all values from api selected by user in variables
                            JSONObject day1resp = jsonObject.getJSONObject("day1");
                            JSONObject day2resp = jsonObject.getJSONObject("day2");
                            JSONObject day3resp = jsonObject.getJSONObject("day3");
                            JSONObject day4resp = jsonObject.getJSONObject("day4");
                            JSONObject day5resp = jsonObject.getJSONObject("day5");
*/
                          /*  //each day and time data is saved to variables
                            d1cals = day1resp.getString("calories_burned");
                            d2cals = day2resp.getString("calories_burned");
                            d3cals = day3resp.getString("calories_burned");
                            d4cals = day4resp.getString("calories_burned");
                            d5cals = day5resp.getString("calories_burned");

                            d1dis = day1resp.getString("distance");
                            d2dis = day2resp.getString("distance");
                            d3dis = day3resp.getString("distance");
                            d4dis = day4resp.getString("distance");
                            d5dis = day5resp.getString("distance");

                            d1hrates = day1resp.getString("hrates");
                            d2hrates = day2resp.getString("hrates");
                            d3hrates = day3resp.getString("hrates");
                            d4hrates = day4resp.getString("hrates");
                            d5hrates = day5resp.getString("hrates");

                            d1steps = day1resp.getString("steps");
                            d2steps = day2resp.getString("steps");
                            d3steps = day3resp.getString("steps");
                            d4steps = day4resp.getString("steps");
                            d5steps = day5resp.getString("steps");





                            Log.e("Response", response.toSring());
                            System.out.println(d1cals + d2cals + d3cals + d4cals + d5cals);
                            System.out.println(response.toString()+"this is my calories read back");




                        } catch (JSONException e) {
                            e.printStackTrace();
                            Toast.makeText(getApplicationContext(), "Authentication Error " + e.toString(), Toast.LENGTH_LONG).show();

                        }
                    }
                },

                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(getApplicationContext(), "Authentication Error " + error.toString(), Toast.LENGTH_LONG).show();

                    }
                }) {
                @Override
                public byte[] getBody() throws AuthFailureError {
                    return body.toString().getBytes();
                }

                @Override
                public String getBodyContentType() {
                    return "application/json";
                }
        };

            // Add the request to the RequestQueue.
        queue.add(stringRequest);
*/

        }
     // end load data

    private void showDateTimeDialog1(final EditText date_time_in1) {
        final Calendar calendar=Calendar.getInstance();
        DatePickerDialog.OnDateSetListener dateSetListener=new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                calendar.set(Calendar.YEAR,year);
                calendar.set(Calendar.MONTH,month);
                calendar.set(Calendar.DAY_OF_MONTH,dayOfMonth);



                TimePickerDialog.OnTimeSetListener timeSetListener=new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                        calendar.set(Calendar.HOUR_OF_DAY,hourOfDay);
                        calendar.set(Calendar.MINUTE,minute);

                        SimpleDateFormat simpleDateFormat=new SimpleDateFormat("yy-MM-dd HH:mm");

                        date_time_in1.setText(simpleDateFormat.format(calendar.getTime()));
                    }
                };

                new TimePickerDialog(test1.this,timeSetListener,calendar.get(Calendar.HOUR_OF_DAY),calendar.get(Calendar.MINUTE),false).show();
            }
        };

        new DatePickerDialog(test1.this,dateSetListener,calendar.get(Calendar.YEAR),calendar.get(Calendar.MONTH),calendar.get(Calendar.DAY_OF_MONTH)).show();

    }



    private void showDateTimeDialog2(final EditText date_time_in2) {
        final Calendar calendar=Calendar.getInstance();
        DatePickerDialog.OnDateSetListener dateSetListener=new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                calendar.set(Calendar.YEAR,year);
                calendar.set(Calendar.MONTH,month);
                calendar.set(Calendar.DAY_OF_MONTH,dayOfMonth);



                TimePickerDialog.OnTimeSetListener timeSetListener=new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                        calendar.set(Calendar.HOUR_OF_DAY,hourOfDay);
                        calendar.set(Calendar.MINUTE,minute);

                        SimpleDateFormat simpleDateFormat=new SimpleDateFormat("yy-MM-dd HH:mm");

                        date_time_in2.setText(simpleDateFormat.format(calendar.getTime()));
                    }
                };

                new TimePickerDialog(test1.this,timeSetListener,calendar.get(Calendar.HOUR_OF_DAY),calendar.get(Calendar.MINUTE),false).show();
            }
        };

        new DatePickerDialog(test1.this,dateSetListener,calendar.get(Calendar.YEAR),calendar.get(Calendar.MONTH),calendar.get(Calendar.DAY_OF_MONTH)).show();

    }




    private void showDateTimeDialog3(final EditText date_time_in3) {
        final Calendar calendar=Calendar.getInstance();
        DatePickerDialog.OnDateSetListener dateSetListener=new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                calendar.set(Calendar.YEAR,year);
                calendar.set(Calendar.MONTH,month);
                calendar.set(Calendar.DAY_OF_MONTH,dayOfMonth);



                TimePickerDialog.OnTimeSetListener timeSetListener=new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                        calendar.set(Calendar.HOUR_OF_DAY,hourOfDay);
                        calendar.set(Calendar.MINUTE,minute);

                        SimpleDateFormat simpleDateFormat=new SimpleDateFormat("yy-MM-dd HH:mm");

                        date_time_in3.setText(simpleDateFormat.format(calendar.getTime()));
                    }
                };

                new TimePickerDialog(test1.this,timeSetListener,calendar.get(Calendar.HOUR_OF_DAY),calendar.get(Calendar.MINUTE),false).show();
            }
        };

        new DatePickerDialog(test1.this,dateSetListener,calendar.get(Calendar.YEAR),calendar.get(Calendar.MONTH),calendar.get(Calendar.DAY_OF_MONTH)).show();

    }


    private void showDateTimeDialog4(final EditText date_time_in4) {
        final Calendar calendar=Calendar.getInstance();
        DatePickerDialog.OnDateSetListener dateSetListener=new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                calendar.set(Calendar.YEAR,year);
                calendar.set(Calendar.MONTH,month);
                calendar.set(Calendar.DAY_OF_MONTH,dayOfMonth);



                TimePickerDialog.OnTimeSetListener timeSetListener=new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                        calendar.set(Calendar.HOUR_OF_DAY,hourOfDay);
                        calendar.set(Calendar.MINUTE,minute);

                        SimpleDateFormat simpleDateFormat=new SimpleDateFormat("yy-MM-dd HH:mm");


                        date_time_in4.setText(simpleDateFormat.format(calendar.getTime()));
                    }
                };

                new TimePickerDialog(test1.this,timeSetListener,calendar.get(Calendar.HOUR_OF_DAY),calendar.get(Calendar.MINUTE),false).show();
            }
        };

        new DatePickerDialog(test1.this,dateSetListener,calendar.get(Calendar.YEAR),calendar.get(Calendar.MONTH),calendar.get(Calendar.DAY_OF_MONTH)).show();

    }


    private void showDateTimeDialog5(final EditText date_time_in5) {
        final Calendar calendar=Calendar.getInstance();
        DatePickerDialog.OnDateSetListener dateSetListener=new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                calendar.set(Calendar.YEAR,year);
                calendar.set(Calendar.MONTH,month);
                calendar.set(Calendar.DAY_OF_MONTH,dayOfMonth);



                TimePickerDialog.OnTimeSetListener timeSetListener=new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                        calendar.set(Calendar.HOUR_OF_DAY,hourOfDay);
                        calendar.set(Calendar.MINUTE,minute);

                        SimpleDateFormat simpleDateFormat=new SimpleDateFormat("yy-MM-dd HH:mm");


                        date_time_in5.setText(simpleDateFormat.format(calendar.getTime()));
                    }
                };

                new TimePickerDialog(test1.this,timeSetListener,calendar.get(Calendar.HOUR_OF_DAY),calendar.get(Calendar.MINUTE),false).show();
            }
        };

        new DatePickerDialog(test1.this,dateSetListener,calendar.get(Calendar.YEAR),calendar.get(Calendar.MONTH),calendar.get(Calendar.DAY_OF_MONTH)).show();

    }




    private void showTimeDialog(final EditText time_in) {
        final Calendar calendar=Calendar.getInstance();

        TimePickerDialog.OnTimeSetListener timeSetListener=new TimePickerDialog.OnTimeSetListener() {
            @Override
            public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                calendar.set(Calendar.HOUR_OF_DAY,hourOfDay);
                calendar.set(Calendar.MINUTE,minute);
                SimpleDateFormat simpleDateFormat=new SimpleDateFormat("HH:mm");
                time_in.setText(simpleDateFormat.format(calendar.getTime()));
            }
        };

        new TimePickerDialog(test1.this,timeSetListener,calendar.get(Calendar.HOUR_OF_DAY),calendar.get(Calendar.MINUTE),false).show();
    }

    private void showDateDialog(final EditText date_in) {
        final Calendar calendar=Calendar.getInstance();
        DatePickerDialog.OnDateSetListener dateSetListener=new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                calendar.set(Calendar.YEAR,year);
                calendar.set(Calendar.MONTH,month);
                calendar.set(Calendar.DAY_OF_MONTH,dayOfMonth);
                SimpleDateFormat simpleDateFormat=new SimpleDateFormat("yy-MM-dd");
                date_in.setText(simpleDateFormat.format(calendar.getTime()));


            }

        };

        new DatePickerDialog(test1.this,dateSetListener,calendar.get(Calendar.YEAR),calendar.get(Calendar.MONTH),calendar.get(Calendar.DAY_OF_MONTH)).show();


    }

}