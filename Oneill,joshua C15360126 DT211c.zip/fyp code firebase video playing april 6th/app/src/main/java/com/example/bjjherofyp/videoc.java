package com.example.bjjherofyp;

public class videoc {


    private String name;



    public videoc(){


        //empty constructor needed

    }


    public videoc(String name) {
        this.name = name;
    }



    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
