package com.example.bjjherofyp;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.anychart.AnyChart;
import com.anychart.AnyChartView;
import com.anychart.chart.common.dataentry.DataEntry;
import com.anychart.chart.common.dataentry.ValueDataEntry;
import com.anychart.charts.Cartesian;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class Fitbit extends AppCompatActivity implements View.OnClickListener {
    EditText calories,hours;
    Button getAllData;
    AnyChartView anyChartView;


    String[] hoursChart ={"monday","tuesday","wednesday","thursday"};
    int[] caloriesChart={600,250,150,550};

    String URL = "http://bjjhero.sytes.net/data?time=12?date=12-01-12";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fitbit);

        calories = (EditText) findViewById(R.id.caloriesRetrieved);
        hours = (EditText) findViewById(R.id.HourWanted);
        getAllData = (Button) findViewById(R.id.getData);

        getAllData.setOnClickListener(this);
        anyChartView=findViewById(R.id.any_chart_view);
       // setupPieChart();
       setupColumnChart();


    }



    public void setupColumnChart(){

          Cartesian bar = AnyChart.column();
        List<DataEntry> dataEntries = new ArrayList<>();

        for(int i=0;i<hoursChart.length;i++){

            dataEntries.add(new ValueDataEntry(hoursChart[i],caloriesChart[i]));

        }


        bar.data(dataEntries);
        anyChartView.setChart(bar);
         bar.title("Calories burnt during training");


    }


 /*  public void setupPieChart(){

       Pie pie = AnyChart.pie();
       List<DataEntry> dataEntries = new ArrayList<>();

       for(int i=0;i<hourspie.length;i++){

           dataEntries.add(new ValueDataEntry(hourspie[i],caloriespie[i]));

       }


       pie.data(dataEntries);
       anyChartView.setChart(pie);


    }*/




    @Override
    public void onClick(View v) {
        if (v == getAllData) {
            loadData();
        }

    }


    public void loadData() {

        // get hour user entered
        String hourUserEntered = hours.getText().toString();

        // Instantiate the RequestQueue.
        RequestQueue queue = Volley.newRequestQueue(this);


        // Request a string response from the provided URL.
        StringRequest stringRequest = new StringRequest(Request.Method.GET, URL+hourUserEntered,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        JSONObject jsonObject = null; // declare JSON object to hold the status
                        try {
                            jsonObject = new JSONObject(response); // get the response and store it into the JSONobject
                            // Get the response from on server,

                            String result = jsonObject.getString("cals_burned").toString();
                            Log.e("Response", response.toString());
                            calories.setText(result);


                        } catch (JSONException e) {
                            e.printStackTrace();
                            Toast.makeText(getApplicationContext(), "Authentication Error " + e.toString(), Toast.LENGTH_LONG).show();

                        }
                    }
                },

                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(getApplicationContext(), "Authentication Error " + error.toString(), Toast.LENGTH_LONG).show();

                    }
                });
        {

            // Add the request to the RequestQueue.
            queue.add(stringRequest);
        }
    }
} // end load data
