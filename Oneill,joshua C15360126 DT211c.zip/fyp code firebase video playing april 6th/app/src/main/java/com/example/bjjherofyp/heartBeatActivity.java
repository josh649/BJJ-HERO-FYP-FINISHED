package com.example.bjjherofyp;


import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

import com.anychart.AnyChart;
import com.anychart.AnyChartView;
import com.anychart.chart.common.dataentry.DataEntry;
import com.anychart.chart.common.dataentry.ValueDataEntry;
import com.anychart.charts.Venn;
import com.anychart.data.Set;

import java.util.ArrayList;
import java.util.List;


public class heartBeatActivity extends AppCompatActivity {


    EditText calories,hours;
    Button getAllData;
    AnyChartView anyChartView;



    String content1;
    String content2;
    String content3;
    String content4;
    String content5;


    String hearbeatmoved1;
    String hearbeatmoved2;
    String hearbeatmoved3;
    String hearbeatmoved4;
    String hearbeatmoved5;



    double hearbeatdouble1;
    double hearbeatdouble2;
    double hearbeatdouble3;
    double hearbeatdouble4;
    double hearbeatdouble5;








    String URL = "http://64.225.99.10:5000/time?time=";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_heart_beat);





        calories = (EditText) findViewById(R.id.caloriesRetrieved);
        hours = (EditText) findViewById(R.id.HourWanted);






        hearbeatmoved1=getIntent().getExtras().getString("value16");

        hearbeatmoved2=getIntent().getExtras().getString("value17");

        hearbeatmoved3=getIntent().getExtras().getString("value18");

        hearbeatmoved4=getIntent().getExtras().getString("value19");

        hearbeatmoved5=getIntent().getExtras().getString("value20");



        content1=getIntent().getExtras().getString("value21");

        content2=getIntent().getExtras().getString("value22");

        content3=getIntent().getExtras().getString("value23");

        content4=getIntent().getExtras().getString("value24");

        content5=getIntent().getExtras().getString("value25");





        hearbeatdouble1 = Double.parseDouble(hearbeatmoved1);
        hearbeatdouble2 = Double.parseDouble(hearbeatmoved2);
        hearbeatdouble3 = Double.parseDouble(hearbeatmoved3);
        hearbeatdouble4 = Double.parseDouble(hearbeatmoved4);
        hearbeatdouble5 = Double.parseDouble(hearbeatmoved5);



        System.out.println(hearbeatdouble1+" " +hearbeatdouble2+" " +hearbeatdouble3+" " +hearbeatdouble4+" "+hearbeatdouble5 +"heartbeat printed from heartbeat ");

        System.out.println(content1+" " +content2+" " +content3+" " +content4 +" "+content5+" content printed from heartbeat");


        anyChartView=findViewById(R.id.any_chart_view);


        String[] hoursChart ={content1,content2,content3,content4,content5};
        double[] caloriesChart={hearbeatdouble1,hearbeatdouble2,hearbeatdouble3,hearbeatdouble4,hearbeatdouble5};


        setupColumnChart(hoursChart,caloriesChart);

    }




    public  void setupColumnChart(String[] hoursChart, double[] caloriesChart){

        Venn venn = AnyChart.venn();

        List<DataEntry> dataEntries = new ArrayList<>();


        Set set = Set.instantiate();
        for(int i=0;i<hoursChart.length;i++){

            dataEntries.add(new ValueDataEntry(hoursChart[i],caloriesChart[i]));

        }


        venn.data(dataEntries);
        anyChartView.setChart(venn);
        venn.title("average heart rate while training");

    }

}
