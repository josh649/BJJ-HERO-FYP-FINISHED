package com.example.bjjherofyp;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

import static android.widget.Toast.makeText;

public class loginActivity extends AppCompatActivity {

    EditText MemberEmail,MemberPassword;
    Button LoginButton,MoveToRegistration;

    String adminEmail = "j@gmail.com";




    FirebaseAuth fAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        MemberEmail = findViewById(R.id.MemberEmail);
        MemberPassword = findViewById(R.id.MemberPassword);
        fAuth = FirebaseAuth.getInstance();
        LoginButton = findViewById(R.id.LoginToMain);
        MoveToRegistration = findViewById(R.id.MoveToRegistration);



        LoginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String email = MemberEmail.getText().toString().trim();
                String password = MemberPassword.getText().toString().trim();

                //check if the email field is empty
                if (TextUtils.isEmpty(email)) {


                    MemberEmail.setError("email is required");
                    return;
                }

                //check if the password field is empty
                if (TextUtils.isEmpty(password)) {


                    MemberPassword.setError("Password Required ");
                    return;
                }


                fAuth.signInWithEmailAndPassword(email,password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {

                        if (task.isSuccessful()){

                            Toast toast1 = Toast.makeText(getApplicationContext(), "login successful",Toast.LENGTH_SHORT);
                            toast1.show();


                            if(email.equals(adminEmail)) {

                                startActivity(new Intent(getApplicationContext(), MainActivity.class));
                                //login was a success

                            }else{

                                startActivity(new Intent(getApplicationContext(),clientSide.class));

                            }


                        }else{
                            //no success when logging in put toast message
                            Toast toast2= makeText(getApplicationContext(),"login failed either password or email is incorrect",Toast.LENGTH_SHORT);
                            toast2.show();
                        }

                    }
                });

                    }
        });


        MoveToRegistration.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                startActivity(new Intent(getApplicationContext(),RegisterAcitivity.class));
            }
        });

    }
}

