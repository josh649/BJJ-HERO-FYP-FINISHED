package com.example.bjjherofyp;

import android.net.Uri;
import android.os.Bundle;
import android.widget.MediaController;
import android.widget.VideoView;

import androidx.appcompat.app.AppCompatActivity;

public class videoActivity extends AppCompatActivity {



    VideoView videoView;
    String VideoSelection;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_video);

        MediaController mediaController = new MediaController(this);

        videoView = findViewById(R.id.vid);
        videoView.setMediaController(mediaController);
        mediaController.setAnchorView(videoView);


        Uri uri = Uri.parse("https://firebasestorage.googleapis.com/v0/b/bjjherofyp1.appspot.com/o/videouploads%2F1576455374312.mp4?alt=media&token=775d958e-5f07-447a-b5c5-d7151e2a8403" );
        videoView.setVideoURI(uri);
        videoView.start();


    }

}
