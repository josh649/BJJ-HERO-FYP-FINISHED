package com.example.bjjherofyp;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

import com.anychart.AnyChart;
import com.anychart.AnyChartView;
import com.anychart.chart.common.dataentry.DataEntry;
import com.anychart.chart.common.dataentry.ValueDataEntry;
import com.anychart.charts.Cartesian;

import java.util.ArrayList;
import java.util.List;


public class distanceActivity extends AppCompatActivity {

    EditText calories, hours;
    Button getAllData;
    AnyChartView anyChartView;


    String content1;
    String content2;
    String content3;
    String content4;
    String content5;

    String distancemoved1;
    String distancemoved2;

    String distancemoved3;

    String distancemoved4;

    String distancemoved5;

    double distancedouble1;
    double distancedouble2;
    double distancedouble3;
    double distancedouble4;
    double distancedouble5;


    String URL = "http://64.225.99.10:5000/time?time=";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_distance);


        calories = (EditText) findViewById(R.id.caloriesRetrieved);
        hours = (EditText) findViewById(R.id.HourWanted);
        getAllData = (Button) findViewById(R.id.getData);


        distancemoved1 = getIntent().getExtras().getString("value11");

        distancemoved2 = getIntent().getExtras().getString("value12");

        distancemoved3 = getIntent().getExtras().getString("value13");

        distancemoved4 = getIntent().getExtras().getString("value14");

        distancemoved5 = getIntent().getExtras().getString("value15");


        content1 = getIntent().getExtras().getString("value21");

        content2 = getIntent().getExtras().getString("value22");

        content3 = getIntent().getExtras().getString("value23");

        content4 = getIntent().getExtras().getString("value24");

        content5 = getIntent().getExtras().getString("value25");


        distancedouble1 = Double.parseDouble(distancemoved1);
        distancedouble2 = Double.parseDouble(distancemoved2);
        distancedouble3 = Double.parseDouble(distancemoved3);
        distancedouble4 = Double.parseDouble(distancemoved4);
        distancedouble5 = Double.parseDouble(distancemoved5);


        System.out.println(distancedouble1 + " " + distancedouble2 + " " + distancedouble3 + " " + distancedouble4 + " " + distancedouble5 + " distance printed from distance");

        System.out.println(content1 + " " + content2 + " " + content3 + " " + content4 + " " + content5 + " content printed from distance");


        String[] hoursChart = {content1, content2, content3, content4, content5};
        double[] caloriesChart = {distancedouble1, distancedouble2, distancedouble3, distancedouble4, distancedouble5};

        anyChartView = findViewById(R.id.any_chart_view);

        setupColumnChart(hoursChart, caloriesChart);

        }

        public  void setupColumnChart(String[] hoursChart, double[] caloriesChart){

            Cartesian bar = AnyChart.column();
            List<DataEntry> dataEntries = new ArrayList<>();

            for(int i=0;i<hoursChart.length;i++){

                dataEntries.add(new ValueDataEntry(hoursChart[i],caloriesChart[i]));

            }


            bar.data(dataEntries);
            anyChartView.setChart(bar);
            bar.title("Distance traveled during training");

        }


    }
