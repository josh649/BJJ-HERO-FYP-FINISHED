package com.example.bjjherofyp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    public Button uploadPictures;
    public Button uploadVideos;
    public Button UploadNote;
    public Button NotesActivityButton;
    public Button clubMembers;
    public Button social;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        uploadPictures = (Button) findViewById(R.id.uploadPics);
        uploadVideos = (Button) findViewById(R.id.uploadVids);




        uploadPictures.setOnClickListener(this);
        uploadVideos.setOnClickListener(this);

    }

    //logs out main user in the application

    public void Logout(View view) {

       // FirebaseAuth.getInstance().signOut();
        startActivity(new Intent(getApplicationContext(), loginActivity.class));
        finish();
    }

    @Override
    public void onClick(View v)
    {
        if (v == uploadPictures)
        {
            // go to different activity
            Intent myIntent = new Intent(this, UploadPicturesActivity.class);
            startActivity(myIntent);
        }
        if(v == uploadVideos)
        {
            // go to different activity
            Intent myIntent = new Intent(this, UploadVideosActivity.class);
            startActivity(myIntent);
        }


    }
}
